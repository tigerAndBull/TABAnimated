//
//  GameTableViewCell.h
//  lifeAndSport
//
//  Created by tigerAndBull on 2018/6/6.
//  Copyright © 2018年 tigerAndBull. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Game;

@interface TestTableViewCell : UITableViewCell

- (void)initWithData:(Game *)game;

@end
